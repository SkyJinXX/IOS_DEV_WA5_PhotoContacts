//
//  File.swift
//  WA4

import Foundation

class Utilities{
    static let phoneTypes: [String] = ["Cell", "Work", "Home"]
}
